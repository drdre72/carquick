import VehicleCatalogClean from "@/components/VehicleCatalogClean";

export default function VehicleCatalogCleanDemo() {
  return (
    <div className="bg-background">
      <VehicleCatalogClean />
    </div>
  );
}
